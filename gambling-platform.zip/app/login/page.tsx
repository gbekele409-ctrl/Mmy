'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

function resolveIdentifier(input: string): string {
  const trimmed = input.trim()
  // If it looks like a phone number (mostly digits, optional leading +),
  // translate to the synthetic internal email used for phone-registered accounts.
  const digitsOnly = trimmed.replace(/[^\d]/g, '')
  const looksLikePhone = /^\+?\d{7,15}$/.test(trimmed)

  if (looksLikePhone) {
    return `${digitsOnly}@phoneusers.internal`
  }
  return trimmed // treat as email
}

export default function LoginPage() {
  const router = useRouter()
  const supabase = createClient()
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const email = resolveIdentifier(identifier)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })

    setLoading(false)

    if (error) {
      setError('Invalid phone/email or password.')
      return
    }

    // route based on role
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', data.user.id)
      .single()

    if (profile?.role === 'admin') router.push('/admin')
    else if (profile?.role === 'agent') router.push('/agent')
    else router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4">
      <form
        onSubmit={handleLogin}
        className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-4"
      >
        <h1 className="text-2xl font-semibold text-white">Log in</h1>

        {error && (
          <div className="text-sm text-red-400 bg-red-950/50 border border-red-900 rounded-lg px-3 py-2">
            {error}
          </div>
        )}

        <div>
          <label className="text-sm text-slate-400">Phone number or email</label>
          <input
            type="text"
            required
            placeholder="+1 555 123 4567 or you@email.com"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-white"
          />
        </div>

        <div>
          <label className="text-sm text-slate-400">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-white"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-semibold py-2.5 transition"
        >
          {loading ? 'Logging in...' : 'Log in'}
        </button>

        <p className="text-sm text-slate-500 text-center">
          No account?{' '}
          <a href="/register" className="text-emerald-400 hover:underline">
            Sign up
          </a>{' '}
          or register via our Telegram bot.
        </p>
      </form>
    </div>
  )
}
