// telegram-bot/registration.js
import { Keyboard, InlineKeyboard } from 'grammy'
import { supabaseAdmin } from './supabase.js'

const MINI_APP_URL = process.env.MINI_APP_URL

function normalizePhone(raw) {
  // keep digits and leading +
  const trimmed = raw.trim()
  const cleaned = trimmed.replace(/[^\d+]/g, '')
  return cleaned.startsWith('+') ? cleaned : `+${cleaned}`
}

function isValidPassword(pw) {
  return typeof pw === 'string' && pw.length >= 8
}

/**
 * grammY conversation: registers a new user via phone number + password.
 * Existing users (matched by telegram_id) skip straight to the menu.
 */
export async function registrationConversation(conversation, ctx) {
  const telegramId = ctx.from.id
  const telegramUsername = ctx.from.username ?? null

  // Already registered?
  const { data: existing } = await conversation.external(() =>
    supabaseAdmin.from('profiles').select('id, phone').eq('telegram_id', telegramId).maybeSingle()
  )

  if (existing) {
    await ctx.reply(
      `Welcome back! You're already registered.`,
      { reply_markup: new InlineKeyboard().webApp('🎮 Open App', MINI_APP_URL) }
    )
    return
  }

  // Step 1: request phone number via Telegram's native contact-share button
  await ctx.reply(
    'Welcome! Let\'s create your account.\n\nFirst, share your phone number using the button below.',
    {
      reply_markup: new Keyboard()
        .requestContact('📱 Share my phone number')
        .resized()
        .oneTime(),
    }
  )

  const contactCtx = await conversation.waitFor(':contact')
  const contact = contactCtx.message.contact

  // Make sure the shared contact actually belongs to the person chatting (not
  // a forwarded contact card for someone else).
  if (contact.user_id !== telegramId) {
    await ctx.reply('That contact card doesn\'t match your account. Please tap the button to share your own number.')
    return await registrationConversation(conversation, ctx)
  }

  const phone = normalizePhone(contact.phone_number)

  // Check phone isn't already used by a different account
  const { data: phoneTaken } = await conversation.external(() =>
    supabaseAdmin.from('profiles').select('id').eq('phone', phone).maybeSingle()
  )

  if (phoneTaken) {
    await ctx.reply(
      'An account already exists with this phone number. Please contact support if this is you and you\'ve lost access.',
      { reply_markup: { remove_keyboard: true } }
    )
    return
  }

  await ctx.reply('Got it. Now choose a password (minimum 8 characters):', {
    reply_markup: { remove_keyboard: true },
  })

  // Step 2: collect password, validate, retry on failure
  let password
  while (true) {
    const pwCtx = await conversation.waitFor('message:text')
    const candidate = pwCtx.message.text

    // Delete the message containing the password for privacy/hygiene
    await conversation.external(() =>
      ctx.api.deleteMessage(ctx.chat.id, pwCtx.message.message_id).catch(() => {})
    )

    if (!isValidPassword(candidate)) {
      await ctx.reply('Password must be at least 8 characters. Try again:')
      continue
    }
    password = candidate
    break
  }

  // Step 3: create the Supabase auth user (synthetic email required by Supabase Auth,
  // phone is the real user-facing identifier and is what they'll log in with on
  // the website too, via a phone-based login flow)
  const syntheticEmail = `${phone.replace('+', '')}@phoneusers.internal`

  const { data: created, error: createErr } = await conversation.external(() =>
    supabaseAdmin.auth.admin.createUser({
      email: syntheticEmail,
      password,
      phone,
      email_confirm: true,
      user_metadata: {
        full_name: ctx.from.first_name ?? 'User',
        telegram_id: telegramId,
        telegram_username: telegramUsername,
      },
    })
  )

  if (createErr || !created?.user) {
    await ctx.reply('Something went wrong creating your account. Please try again with /start, or contact support.')
    return
  }

  // Backfill telegram_id/username/phone on the profile (trigger already created the row)
  await conversation.external(() =>
    supabaseAdmin
      .from('profiles')
      .update({ telegram_id: telegramId, telegram_username: telegramUsername, phone })
      .eq('id', created.user.id)
  )

  await ctx.reply(
    '✅ Account created! You can now open the app to deposit and play.\n\n' +
      'You can also log in on the website using your phone number and the password you just set.',
    { reply_markup: new InlineKeyboard().webApp('🎮 Open App', MINI_APP_URL) }
  )
}
