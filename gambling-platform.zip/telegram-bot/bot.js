// telegram-bot/bot.js
import 'dotenv/config'
import { Bot, session } from 'grammy'
import { conversations, createConversation } from '@grammyjs/conversations'
import { registrationConversation } from './registration.js'

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
const MINI_APP_URL = process.env.MINI_APP_URL

if (!BOT_TOKEN) throw new Error('Missing TELEGRAM_BOT_TOKEN in .env')
if (!MINI_APP_URL) throw new Error('Missing MINI_APP_URL in .env')

const bot = new Bot(BOT_TOKEN)

bot.use(session({ initial: () => ({}) }))
bot.use(conversations())
bot.use(createConversation(registrationConversation, 'registration'))

bot.command('start', async (ctx) => {
  await ctx.conversation.enter('registration')
})

bot.command('help', async (ctx) => {
  await ctx.reply(
    'Use /start to register or open the app.\n' +
      'Once registered, use /start again anytime to get the app link.'
  )
})

bot.catch((err) => {
  console.error('Bot error:', err)
})

bot.start()
console.log('Telegram bot started.')
