// lib/server/rateLimit.ts
//
// SERVER-ONLY. Simple sliding-window rate limiter backed by a Postgres table
// (works across Vercel's stateless serverless instances, unlike in-memory
// counters which reset per cold start / don't share state across instances).
// Requires the `rate_limit_hits` table from supabase/schema.sql.

import { createAdminClient } from '@/lib/supabase/server'

export async function checkRateLimit(opts: {
  key: string          // e.g. `register:ip:1.2.3.4` or `otp:phone:+1555...`
  maxAttempts: number
  windowSeconds: number
}): Promise<{ allowed: boolean; remaining: number }> {
  const admin = createAdminClient()
  const windowStart = new Date(Date.now() - opts.windowSeconds * 1000).toISOString()

  const { count } = await admin
    .from('rate_limit_hits')
    .select('*', { count: 'exact', head: true })
    .eq('key', opts.key)
    .gte('created_at', windowStart)

  const currentCount = count ?? 0

  if (currentCount >= opts.maxAttempts) {
    return { allowed: false, remaining: 0 }
  }

  await admin.from('rate_limit_hits').insert({ key: opts.key })

  return { allowed: true, remaining: opts.maxAttempts - currentCount - 1 }
}
