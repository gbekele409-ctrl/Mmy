// lib/server/recaptcha.ts
//
// SERVER-ONLY. Never import this into a 'use client' component — it uses
// the reCAPTCHA secret key, which must never reach the browser bundle.

const RECAPTCHA_SECRET = process.env.RECAPTCHA_SECRET_KEY!
const MIN_SCORE = 0.5 // reCAPTCHA v3 returns a 0-1 bot-likelihood score

export async function verifyRecaptcha(token: string, expectedAction: string): Promise<{
  ok: boolean
  reason?: string
}> {
  if (!token) return { ok: false, reason: 'missing_token' }

  const res = await fetch('https://www.google.com/recaptcha/api/siteverify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ secret: RECAPTCHA_SECRET, response: token }),
  })

  const data = await res.json()

  if (!data.success) return { ok: false, reason: 'verification_failed' }
  if (data.action !== expectedAction) return { ok: false, reason: 'action_mismatch' }
  if (data.score < MIN_SCORE) return { ok: false, reason: 'low_score' }

  return { ok: true }
}
