# Gambling Platform — Website + Telegram Mini App

## Architecture

- **Next.js website** (`/app`) — main product, works standalone in a browser
- **Supabase** — auth, database, RLS (shared backend for both website and bot)
- **Telegram bot** (`/telegram-bot`) — registers users via phone number
  (Telegram's native contact-share button) + a password they type in chat,
  creates a real Supabase Auth account, then opens the website as a Telegram
  Mini App (WebApp)

Website users and Telegram-registered users are the SAME account type: a
phone-registered user can log in on the website too using their phone number
+ the password they set in the bot (an internal synthetic email is used
under the hood since Supabase Auth requires one, but the user never sees it).

## Setup order

### 1. Supabase project
1. Create a project at supabase.com.
2. Run `supabase/schema.sql` in the SQL editor.
3. Create the storage bucket for deposit proofs:
   ```sql
   insert into storage.buckets (id, name, public) values ('deposit-proofs', 'deposit-proofs', false);
   ```
   Then add a storage policy so users can upload only to their own folder
   (e.g. path prefixed with their `auth.uid()`), and agents/admins can read all.
4. Copy your Project URL + anon key into `.env.local` (see `.env.local.example`).

### 2. Telegram bot
1. Talk to [@BotFather](https://t.me/BotFather), run `/newbot`, get your token.
2. In BotFather, run `/setmenubutton` (or `/mybots` → Bot Settings → Menu
   Button) and set it to your deployed site URL once live.
3. Copy `telegram-bot/.env.example` to `telegram-bot/.env` and fill in
   `TELEGRAM_BOT_TOKEN`, `MINI_APP_URL`, `SUPABASE_URL`, and
   `SUPABASE_SERVICE_ROLE_KEY`.
4. `cd telegram-bot && npm install && npm start` (deploy as a persistent
   process — Railway/Fly.io/a VPS — it can't run on Vercel's serverless model
   unless rewritten for webhook mode).

### 3. Website
1. `npm install`
2. Copy `.env.local.example` to `.env.local`, fill in your Supabase URL/anon key.
3. `npm run dev` to test locally, deploy to Vercel (or similar) for production.

## Security notes (read before going live)

- **RLS is doing the real access control.** The service role key
  (`SUPABASE_SERVICE_ROLE_KEY`) bypasses RLS entirely — it lives only in the
  bot's server-side `.env` and must never reach client-side code or a public
  repo.
- **Passwords typed into the bot chat are deleted immediately** after
  submission (see `registration.js`) to avoid leaving them sitting in chat
  history, but Telegram chat transport itself is not end-to-end encrypted for
  bots — this is an inherent limitation of collecting passwords via a bot
  chat, worth knowing about even though we mitigate what we can.
- **Contact-share verification**: the bot checks that the shared contact's
  `user_id` matches the chatting user, to stop someone from forwarding
  someone else's contact card to register in their name.
- **Agents are scoped to their assigned users** at the database function
  level (`approve_deposit`/`approve_withdrawal`), not just hidden in the UI.
- **This still assumes:** a certified/audited RNG source or confirmation that
  the provably-fair seed-based RNG here meets your license's requirements,
  a real KYC provider if your license requires identity verification beyond
  what's collected here, and that all real money movement (bank transfers,
  agent cash handling) happens outside this code — the platform only records
  it accurately once an agent/admin confirms it happened.
