-- ============================================================
-- GAMBLING PLATFORM SCHEMA
-- Roles: admin, agent, user
-- Money flow: manual deposit/withdrawal requests approved by admin/agent
-- ============================================================

-- ---------- EXTENSIONS ----------
create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

-- ---------- ENUMS ----------
create type user_role as enum ('admin', 'agent', 'user');
create type request_status as enum ('pending', 'approved', 'rejected');
create type transaction_type as enum ('deposit', 'withdrawal', 'bet', 'win', 'adjustment');
create type game_status as enum ('active', 'inactive');

-- ============================================================
-- PROFILES (extends auth.users)
-- ============================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text unique,
  telegram_id bigint unique,        -- optional link if they registered via bot
  telegram_username text,
  role user_role not null default 'user',
  agent_id uuid references public.profiles(id), -- which agent this user is assigned to (optional)
  is_banned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_profiles_role on public.profiles(role);
create index idx_profiles_agent_id on public.profiles(agent_id);
create index idx_profiles_telegram_id on public.profiles(telegram_id);
create index idx_profiles_phone on public.profiles(phone);

-- ============================================================
-- WALLETS
-- ============================================================
create table public.wallets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  balance numeric(14,2) not null default 0 check (balance >= 0),
  currency text not null default 'USD',
  updated_at timestamptz not null default now()
);

-- ============================================================
-- DEPOSIT REQUESTS
-- ============================================================
create table public.deposit_requests (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(14,2) not null check (amount > 0),
  payment_reference text,           -- e.g. transaction/reference number
  proof_url text,                   -- screenshot uploaded to storage
  status request_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now()
);

create index idx_deposit_status on public.deposit_requests(status);
create index idx_deposit_user on public.deposit_requests(user_id);

-- ============================================================
-- WITHDRAWAL REQUESTS
-- ============================================================
create table public.withdrawal_requests (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(14,2) not null check (amount > 0),
  payout_details text not null,     -- bank account / mobile money / etc.
  status request_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now()
);

create index idx_withdrawal_status on public.withdrawal_requests(status);
create index idx_withdrawal_user on public.withdrawal_requests(user_id);

-- ============================================================
-- TRANSACTIONS (immutable ledger)
-- ============================================================
create table public.transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type transaction_type not null,
  amount numeric(14,2) not null,     -- positive = credit, negative = debit
  balance_after numeric(14,2) not null,
  reference_id uuid,                 -- links to deposit_requests / withdrawal_requests / game round
  note text,
  created_by uuid references public.profiles(id), -- who triggered it (admin/agent/system)
  created_at timestamptz not null default now()
);

create index idx_transactions_user on public.transactions(user_id);
create index idx_transactions_type on public.transactions(type);

-- ============================================================
-- GAMES (admin-managed catalog)
-- ============================================================
create table public.games (
  id uuid primary key default uuid_generate_v4(),
  slug text not null unique,          -- e.g. 'aviator'
  name text not null,
  description text,
  thumbnail_url text,
  status game_status not null default 'active',
  min_bet numeric(14,2) not null default 1,
  max_bet numeric(14,2) not null default 1000,
  config jsonb not null default '{}', -- game-specific settings (house edge, max multiplier, etc.)
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- AVIATOR ROUNDS
-- ============================================================
create table public.aviator_rounds (
  id uuid primary key default uuid_generate_v4(),
  round_number bigserial,
  server_seed text not null,          -- revealed after round ends (provably fair)
  server_seed_hash text not null,     -- shown to players before round starts
  client_seed text,                   -- optional, can combine with public entropy
  crash_multiplier numeric(10,2),     -- null while round in progress
  status text not null default 'running', -- running | crashed
  started_at timestamptz not null default now(),
  crashed_at timestamptz
);

create index idx_aviator_rounds_status on public.aviator_rounds(status);

-- ============================================================
-- AVIATOR BETS
-- ============================================================
create table public.aviator_bets (
  id uuid primary key default uuid_generate_v4(),
  round_id uuid not null references public.aviator_rounds(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  bet_amount numeric(14,2) not null check (bet_amount > 0),
  cashout_multiplier numeric(10,2),   -- null = did not cash out (lost)
  payout numeric(14,2) not null default 0,
  status text not null default 'placed', -- placed | cashed_out | lost
  created_at timestamptz not null default now()
);

create index idx_aviator_bets_round on public.aviator_bets(round_id);
create index idx_aviator_bets_user on public.aviator_bets(user_id);

-- ============================================================
-- FUNCTIONS: helper to check role
-- ============================================================
create or replace function public.current_role()
returns user_role
language sql stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.is_agent_or_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role in ('agent','admin'));
$$;

-- ============================================================
-- FUNCTION: approve deposit (atomic - updates request + wallet + ledger)
-- ============================================================
create or replace function public.approve_deposit(p_request_id uuid, p_reviewer_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_request record;
  v_reviewer record;
  v_new_balance numeric(14,2);
begin
  -- reviewer must actually be the authenticated caller, and must be agent/admin
  if p_reviewer_id <> auth.uid() then
    raise exception 'Reviewer id must match authenticated user';
  end if;

  select * into v_reviewer from public.profiles where id = p_reviewer_id;
  if v_reviewer is null or v_reviewer.role not in ('agent','admin') then
    raise exception 'Not authorized to approve deposits';
  end if;

  select * into v_request from public.deposit_requests where id = p_request_id for update;

  if v_request is null then
    raise exception 'Deposit request not found';
  end if;

  if v_request.status <> 'pending' then
    raise exception 'Request already processed';
  end if;

  -- agents may only approve requests from users assigned to them; admins approve any
  if v_reviewer.role = 'agent' then
    if not exists (
      select 1 from public.profiles
      where id = v_request.user_id and agent_id = p_reviewer_id
    ) then
      raise exception 'Agents may only approve requests for their assigned users';
    end if;
  end if;

  update public.deposit_requests
    set status = 'approved', reviewed_by = p_reviewer_id, reviewed_at = now()
    where id = p_request_id;

  update public.wallets
    set balance = balance + v_request.amount, updated_at = now()
    where user_id = v_request.user_id
    returning balance into v_new_balance;

  insert into public.transactions (user_id, type, amount, balance_after, reference_id, created_by, note)
    values (v_request.user_id, 'deposit', v_request.amount, v_new_balance, p_request_id, p_reviewer_id, 'Deposit approved');
end;
$$;

-- ============================================================
-- FUNCTION: approve withdrawal (atomic - checks balance, deducts, logs)
-- ============================================================
create or replace function public.approve_withdrawal(p_request_id uuid, p_reviewer_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_request record;
  v_reviewer record;
  v_wallet record;
  v_new_balance numeric(14,2);
begin
  if p_reviewer_id <> auth.uid() then
    raise exception 'Reviewer id must match authenticated user';
  end if;

  select * into v_reviewer from public.profiles where id = p_reviewer_id;
  if v_reviewer is null or v_reviewer.role not in ('agent','admin') then
    raise exception 'Not authorized to approve withdrawals';
  end if;

  select * into v_request from public.withdrawal_requests where id = p_request_id for update;

  if v_request is null then
    raise exception 'Withdrawal request not found';
  end if;

  if v_request.status <> 'pending' then
    raise exception 'Request already processed';
  end if;

  if v_reviewer.role = 'agent' then
    if not exists (
      select 1 from public.profiles
      where id = v_request.user_id and agent_id = p_reviewer_id
    ) then
      raise exception 'Agents may only approve requests for their assigned users';
    end if;
  end if;

  select * into v_wallet from public.wallets where user_id = v_request.user_id for update;

  if v_wallet.balance < v_request.amount then
    raise exception 'Insufficient balance';
  end if;

  update public.withdrawal_requests
    set status = 'approved', reviewed_by = p_reviewer_id, reviewed_at = now()
    where id = p_request_id;

  update public.wallets
    set balance = balance - v_request.amount, updated_at = now()
    where user_id = v_request.user_id
    returning balance into v_new_balance;

  insert into public.transactions (user_id, type, amount, balance_after, reference_id, created_by, note)
    values (v_request.user_id, 'withdrawal', -v_request.amount, v_new_balance, p_request_id, p_reviewer_id, 'Withdrawal approved');
end;
$$;

-- ============================================================
-- TRIGGER: auto-create wallet + profile on signup
-- ============================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, new.raw_user_meta_data->>'full_name', 'user');

  insert into public.wallets (user_id, balance)
  values (new.id, 0);

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.deposit_requests enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.transactions enable row level security;
alter table public.games enable row level security;
alter table public.aviator_rounds enable row level security;
alter table public.aviator_bets enable row level security;

-- PROFILES
create policy "Users view own profile" on public.profiles for select
  using (auth.uid() = id or public.is_agent_or_admin());
create policy "Users update own profile" on public.profiles for update
  using (auth.uid() = id);
create policy "Admins manage all profiles" on public.profiles for all
  using (public.is_admin());

-- WALLETS
create policy "Users view own wallet" on public.wallets for select
  using (auth.uid() = user_id or public.is_agent_or_admin());
-- No direct client-side insert/update/delete: wallet changes only via SECURITY DEFINER functions or admin.
create policy "Admins manage wallets" on public.wallets for all
  using (public.is_admin());

-- DEPOSIT REQUESTS
create policy "Users view own deposit requests" on public.deposit_requests for select
  using (auth.uid() = user_id or public.is_agent_or_admin());
create policy "Users create own deposit requests" on public.deposit_requests for insert
  with check (auth.uid() = user_id);
create policy "Agents/Admins update deposit requests" on public.deposit_requests for update
  using (public.is_agent_or_admin());

-- WITHDRAWAL REQUESTS
create policy "Users view own withdrawal requests" on public.withdrawal_requests for select
  using (auth.uid() = user_id or public.is_agent_or_admin());
create policy "Users create own withdrawal requests" on public.withdrawal_requests for insert
  with check (auth.uid() = user_id);
create policy "Agents/Admins update withdrawal requests" on public.withdrawal_requests for update
  using (public.is_agent_or_admin());

-- TRANSACTIONS (read-only for users, system writes via functions)
create policy "Users view own transactions" on public.transactions for select
  using (auth.uid() = user_id or public.is_agent_or_admin());

-- GAMES (public read for active games, admin manages)
create policy "Anyone can view active games" on public.games for select
  using (status = 'active' or public.is_admin());
create policy "Admins manage games" on public.games for all
  using (public.is_admin());

-- AVIATOR ROUNDS (public read)
create policy "Anyone can view rounds" on public.aviator_rounds for select
  using (true);

-- AVIATOR BETS
create policy "Users view own bets, admins view all" on public.aviator_bets for select
  using (auth.uid() = user_id or public.is_agent_or_admin());
create policy "Users place own bets" on public.aviator_bets for insert
  with check (auth.uid() = user_id);
create policy "Users update own bets to cash out" on public.aviator_bets for update
  using (auth.uid() = user_id and status = 'placed');

-- ============================================================
-- RATE LIMITING (backs lib/server/rateLimit.ts)
-- ============================================================
create table public.rate_limit_hits (
  id bigserial primary key,
  key text not null,
  created_at timestamptz not null default now()
);

create index idx_rate_limit_key_time on public.rate_limit_hits(key, created_at);

-- Housekeeping: old rows can be purged periodically (e.g. via a cron job /
-- pg_cron) since we only ever query recent windows.
alter table public.rate_limit_hits enable row level security;
-- No client policies at all: only the service-role key (server-only) touches this table.

-- ============================================================
-- OTP VERIFICATIONS (phone verification during website registration)
-- ============================================================
create table public.otp_verifications (
  id uuid primary key default uuid_generate_v4(),
  phone text not null,
  code_hash text not null,        -- never store the raw OTP code
  attempts int not null default 0,
  verified boolean not null default false,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create index idx_otp_phone on public.otp_verifications(phone);
alter table public.otp_verifications enable row level security;
-- No client policies: only service-role (server-only API routes) touches this table.


